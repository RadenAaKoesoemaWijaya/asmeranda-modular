"""Backend configuration & dependency helpers."""
